#ifndef MYPROJECT_MATH_FACTORIAL_H
#define MYPROJECT_MATH_FACTORIAL_H

/** @ingroup group_math */
namespace myproject {
    namespace math {

        /** @ingroup group_math */
        int fact(int n);
    }
}
#endif
