//===--- builtins_with_mapping-d1.h - test input file for iwyu ------------===//
//
//                     The LLVM Compiler Infrastructure
//
// This file is distributed under the University of Illinois Open Source
// License. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//

#ifndef INCLUDE_WHAT_YOU_USE_TESTS_CXX_BUILTINS_WITH_MAPPING_D1_H_
#define INCLUDE_WHAT_YOU_USE_TESTS_CXX_BUILTINS_WITH_MAPPING_D1_H_

int i = __builtin_expect(0, 0);

#endif  // INCLUDE_WHAT_YOU_USE_TESTS_CXX_BUILTINS_WITH_MAPPING_D1_H_
