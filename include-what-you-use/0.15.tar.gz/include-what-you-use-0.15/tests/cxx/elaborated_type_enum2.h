//===--- elaborated_type_enum2.h - test input file for iwyu ---------------===//
//
//                     The LLVM Compiler Infrastructure
//
// This file is distributed under the University of Illinois Open Source
// License. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//

enum ElaborationEnum2 {
  EE2_First,
  EE2_Second
};
