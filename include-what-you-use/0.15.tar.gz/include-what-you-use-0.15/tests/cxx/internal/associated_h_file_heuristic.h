//===--- associated_h_file_heuristic.h - test input file for iwyu ---------===//
//
//                     The LLVM Compiler Infrastructure
//
// This file is distributed under the University of Illinois Open Source
// License. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//

const int kUnused = 1;

/**** IWYU_SUMMARY

(tests/cxx/internal/associated_h_file_heuristic.h has correct #includes/fwd-decls)

***** IWYU_SUMMARY */
