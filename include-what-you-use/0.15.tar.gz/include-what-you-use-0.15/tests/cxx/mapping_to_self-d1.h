//===--- mapping_to_self-d1.h - test input file for iwyu ------------------===//
//
//                     The LLVM Compiler Infrastructure
//
// This file is distributed under the University of Illinois Open Source
// License. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//

#ifndef INCLUDE_WHAT_YOU_USE_TESTS_CXX_MAPPING_TO_SELF_D1_H_
#define INCLUDE_WHAT_YOU_USE_TESTS_CXX_MAPPING_TO_SELF_D1_H_

#include "tests/cxx/mapping_to_self-i1.h"

#endif // INCLUDE_WHAT_YOU_USE_TESTS_CXX_MAPPING_TO_SELF_D1_H_
