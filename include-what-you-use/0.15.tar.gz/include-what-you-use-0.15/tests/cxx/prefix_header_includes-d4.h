//===--- prefix_header_includes-d4.h - test input file for iwyu -----------===//
//
//                     The LLVM Compiler Infrastructure
//
// This file is distributed under the University of Illinois Open Source
// License. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//

#ifndef INCLUDE_WHAT_YOU_USE_TESTS_CXX_PREFIX_HEADER_INCLUDES_D4_H_
#define INCLUDE_WHAT_YOU_USE_TESTS_CXX_PREFIX_HEADER_INCLUDES_D4_H_

class CommandLineIncludeD4 {};

#endif  // INCLUDE_WHAT_YOU_USE_TESTS_CXX_PREFIX_HEADER_INCLUDES_D4_H_
