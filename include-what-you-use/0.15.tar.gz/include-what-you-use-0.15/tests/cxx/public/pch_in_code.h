//===--- pch_in_code.h - test input file for iwyu ---------*- C++ -*-------===//
//
//                     The LLVM Compiler Infrastructure
//
// This file is distributed under the University of Illinois Open Source
// License. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//

/**** IWYU_SUMMARY

(tests/cxx/public/pch_in_code.h has correct #includes/fwd-decls)

***** IWYU_SUMMARY */

