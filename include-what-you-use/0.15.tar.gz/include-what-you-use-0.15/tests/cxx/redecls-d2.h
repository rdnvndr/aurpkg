//===--- redecls-d2.h - test input file for iwyu --------------------------===//
//
//                     The LLVM Compiler Infrastructure
//
// This file is distributed under the University of Illinois Open Source
// License. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//

// This looks suspiciously like redecls-d1.h.  :-)

typedef int MyTypedef;
void Fn();
extern float var;
