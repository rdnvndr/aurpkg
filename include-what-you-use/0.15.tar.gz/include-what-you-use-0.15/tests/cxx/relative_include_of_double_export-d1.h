//===--- relative_include_of_double_export-d1.h - test input --------------===//
//
//                     The LLVM Compiler Infrastructure
//
// This file is distributed under the University of Illinois Open Source
// License. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//

#ifndef INCLUDE_WHAT_YOU_USE_TESTS_CXX_RELATIVE_INCLUDE_OF_DOUBLE_EXPORT_D1_H_
#define INCLUDE_WHAT_YOU_USE_TESTS_CXX_RELATIVE_INCLUDE_OF_DOUBLE_EXPORT_D1_H_

#include "export_private_near.h" // IWYU pragma: export

#endif // INCLUDE_WHAT_YOU_USE_TESTS_CXX_RELATIVE_INCLUDE_OF_DOUBLE_EXPORT_D1_H_
