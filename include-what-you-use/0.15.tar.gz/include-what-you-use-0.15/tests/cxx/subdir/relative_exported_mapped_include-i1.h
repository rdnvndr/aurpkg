//===--- relative_exported_mapped_include-i1.h - test input file ----------===//
//
//                     The LLVM Compiler Infrastructure
//
// This file is distributed under the University of Illinois Open Source
// License. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//

#ifndef INCLUDE_WHAT_YOU_USE_TESTS_CXX_RELATIVE_EXPORTED_MAPPED_INCLUDE_I1_H_
#define INCLUDE_WHAT_YOU_USE_TESTS_CXX_RELATIVE_EXPORTED_MAPPED_INCLUDE_I1_H_

enum MappedToExportedHeader {};

#endif // INCLUDE_WHAT_YOU_USE_TESTS_CXX_RELATIVE_EXPORTED_MAPPED_INCLUDE_I1_H_
