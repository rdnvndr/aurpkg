Vombatidae color theme for Mutt
===============================

Mutt color scheme. Some of the colors are
inspired by the wombat Vim color scheme.

Screenshots
-----------

![Screenshot 1](http://www.haeggblad.com/vombatidae/img/vombatidae-mutt1.png)
![Screenshot 2](http://www.haeggblad.com/vombatidae/img/vombatidae-mutt2.png)

Download
--------

- Web page is at: http://www.haeggblad.com/vombatidae
- Code is hosted at: https://github.com/octol/vombatidae-mutt

Author: Jon Haggblad <jon@haeggblad.com>
Initial version: Fri, 17 May 2013

