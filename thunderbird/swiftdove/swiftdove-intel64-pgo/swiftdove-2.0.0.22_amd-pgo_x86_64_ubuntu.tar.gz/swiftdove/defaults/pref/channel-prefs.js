//@line 2 "/build/sdmake/mozilla/mail/app/profile/channel-prefs.js"
pref("app.update.channel", "default");
