// Default start page
pref("mailnews.start_page.url","chrome://messenger/content/start.xhtml");

// first launch welcome page
pref("mailnews.start_page.welcome_url","chrome://messenger/content/start.xhtml");

// start page override to load after an update
pref("mailnews.start_page.override_url","chrome://messenger/content/start.xhtml");
