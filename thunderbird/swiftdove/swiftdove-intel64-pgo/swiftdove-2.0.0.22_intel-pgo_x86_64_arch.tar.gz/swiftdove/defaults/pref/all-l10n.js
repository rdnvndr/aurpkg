//@line 36 "/build/sdmake/mozilla/mail/locales/en-US/all-l10n.js"

//@line 38 "/build/sdmake/mozilla/mail/locales/en-US/all-l10n.js"

pref("general.useragent.locale", "en-US");
pref("spellchecker.dictionary", "en-US");
